package com.example.daiwj.universalitemdecoration.itemdecoration;

import android.graphics.Canvas;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.daiwj.universalitemdecoration.Item;
import com.example.daiwj.universalitemdecoration.MainActivity;
import com.example.daiwj.universalitemdecoration.Product;

/**
 * 描述:
 * 作者: daiwj on 2018/9/12 11:52
 */
public class CartGridDivider extends GridDivider {

    @Override
    public void draw(Canvas c, RecyclerView parent, View child, Divider divider, UniversalItemDecoration decoration) {

        MainActivity.MyAdapter adapter = (MainActivity.MyAdapter) parent.getAdapter();
        int itemPosition = parent.getChildAdapterPosition(child);

        Item item = adapter.getItem(itemPosition);

        if (item instanceof Product) {
            super.drawVertical(c, parent, child, divider, decoration);
        }
    }
}
