package com.example.daiwj.universalitemdecoration.itemdecoration;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

import java.util.List;

/**
 * 描述:
 * 作者: daiwj on 2018/9/7 16:11
 */
public class DefaultDividerFactory implements DividerFactory {

    public LinearDivider getDefaultLinearDivider(Context context, UniversalItemDecoration decoration) {
        LinearDivider divider = new LinearDivider();
        divider.setDividerSize(40);
        return divider;
    }

    public GridDivider getDefaultGridDivider(Context context, UniversalItemDecoration decoration) {
        CartGridDivider divider = new CartGridDivider();
        divider.setDrawable(new ColorDrawable(Color.parseColor("#f2f3f4")));
        divider.setDrawableWidth(20);
        divider.setDrawableHeight(20);
        divider.setVerticalOffset(40);
        divider.setHorizontalOffset(40);
        divider.setEdgeSize(40);
        return divider;
    }

    public StaggerGridDivider getDefaultStaggerGridDivider(Context context, UniversalItemDecoration decoration) {
        StaggerGridDivider divider = new StaggerGridDivider();
        divider.setDrawable(new ColorDrawable(Color.parseColor("#f2f3f4")));
        divider.setDrawableWidth(20);
        divider.setDrawableHeight(20);
        divider.setVerticalOffset(40);
        divider.setHorizontalOffset(40);
        divider.setEdgeSize(40);
        return divider;
    }

    public List<Divider> getDividers(Context context) {
        return null;
    }

}
